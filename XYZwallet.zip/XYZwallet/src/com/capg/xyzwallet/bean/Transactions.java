package com.capg.xyzwallet.bean;

public class Transactions {

}
