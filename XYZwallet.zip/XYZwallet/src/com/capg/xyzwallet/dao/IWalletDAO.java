package com.capg.xyzwallet.dao;

public interface IWalletDAO {

}
