package com.capg.xyzwallet.dao;

public class WalletDAOImp {

}
