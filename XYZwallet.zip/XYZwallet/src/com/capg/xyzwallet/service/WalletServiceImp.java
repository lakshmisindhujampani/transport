package com.capg.xyzwallet.service;

import java.util.ArrayList;

import com.capg.xyzwallet.bean.Transactions;
import com.capg.xyzwallet.bean.WalletBean;

public class WalletServiceImp implements IWalletService{

	@Override
	public boolean createAccount(WalletBean w) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public double showBalance(long accNum, int pin) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean deposit(long accNum, int pin, double amount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean withdraw(long accNum, int pin, double amount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean fundTransfer(long accNum1, long accNum2, int pin,
			double amount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ArrayList<Transactions> printTransaction(long accNum, int pin) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean checkAccNum(long accNum) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean checkPin(int Pin) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateWallet(WalletBean w) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateAccNum(long accNum) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validatePin(int pin) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateAmount(double amount) {
		// TODO Auto-generated method stub
		return false;
	}

}
