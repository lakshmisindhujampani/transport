package com.capg.xyzwallet.service;

import java.util.ArrayList;

import com.capg.xyzwallet.bean.Transactions;
import com.capg.xyzwallet.bean.WalletBean;

public interface IWalletService {

	public boolean createAccount(WalletBean w);
	public double showBalance(long accNum,int pin);
	public boolean deposit(long accNum,int pin,double amount);
	public boolean withdraw(long accNum,int pin,double amount);
	public boolean fundTransfer(long accNum1,long accNum2,int pin,double amount);
	public ArrayList<Transactions> printTransaction(long accNum,int pin);
	
	
	public boolean checkAccNum(long accNum);
	public boolean checkPin(int Pin);
	
	public boolean validateWallet(WalletBean w);
	public boolean validateAccNum(long accNum);
	public boolean validatePin(int pin);
	public boolean validateAmount(double amount);
}
